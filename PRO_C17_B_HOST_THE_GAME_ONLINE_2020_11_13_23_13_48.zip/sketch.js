
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var ground

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600, 200);
  
  
  
  
  monkey = createSprite(300,170,50,50)         
  monkey.addAnimation("monl",monkey_running)
  monkey.scale = 0.08
  monkey.velocityY = monkey.velocityY +5   ;
  
  ground = createSprite(300,175,600,10)
  
  
  

  

  
}


function draw() {
background("white");
  
  
  drawSprites()
  
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600,150,10,40);
    obstacle.velocityX = -5
    obstacle.addImage ("rock",obstaceImage)
    obstacle.scale = 0.1
  }
    
    if(frameCount % 70 === 0) {
    var banana = createSprite(600,50,10,40);
    banana.velocityX = -5
    banana.addImage ("banana",bananaImage)
    banana.scale = 0.1
    }
  
   if(keyDown("space")){
      monkey.velocityY = -12;
    }
  monkey.velocityY = monkey.velocityY +12;
  

  monkey.collide(ground);

 if(keyDown("space")){
      monkey.velocityY = -12;
  
}
} 